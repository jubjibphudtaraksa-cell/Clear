package com.fiatx2.autoclear;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Boss;
import org.bukkit.entity.Enemy;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.plugin.java.JavaPlugin;

public class AutoClear extends JavaPlugin implements CommandExecutor {

    private int interval;
    private int seconds;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        interval = Math.max(30, getConfig().getInt("interval-seconds", 600));
        seconds = interval;

        getCommand("clearworld").setExecutor(this);
        getServer().getPluginManager().registerEvents(new SpawnerListener(), this);

        Bukkit.getScheduler().runTaskTimer(this, () -> {
            seconds--;
            if (seconds == 30 || (seconds >= 1 && seconds <= 10)) {
                broadcast("จะเคลียร์ไอเทมและมอนสเตอร์ใน " + seconds + " วินาที!", NamedTextColor.YELLOW);
            }
            if (seconds <= 0) {
                runClear();
                seconds = interval;
            }
        }, 20L, 20L);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("autoclear.clearworld")) {
            sender.sendMessage(Component.text("คุณไม่มีสิทธิ์ใช้คำสั่งนี้", NamedTextColor.RED));
            return true;
        }
        runClear();
        seconds = interval; // รีเซ็ตเวลานับถอยหลัง
        return true;
    }

    private void runClear() {
        int items = 0, mobs = 0;
        for (World world : Bukkit.getWorlds()) {
            for (Entity e : world.getEntities()) {
                if (e instanceof Item) {
                    e.remove();
                    items++;
                } else if (e instanceof Enemy && !(e instanceof Boss) && e.customName() == null) {
                    e.remove();
                    mobs++;
                }
            }
        }
        broadcast("เคลียร์แล้ว! ไอเทม " + items + " ชิ้น, มอนสเตอร์ " + mobs + " ตัว", NamedTextColor.GREEN);
    }

    private void broadcast(String msg, NamedTextColor color) {
        Bukkit.broadcast(Component.text("[AutoClear] ", NamedTextColor.GOLD)
                .append(Component.text(msg, color)));
    }
}
